export interface IMapArea {
    x?: string;
    y?: string;
    width?: string;
    height?: string;
    url?: string;
    openInNewWindow?: boolean;
    imapType?: string;
    d?: string;
}
//# sourceMappingURL=IMapArea.d.ts.map