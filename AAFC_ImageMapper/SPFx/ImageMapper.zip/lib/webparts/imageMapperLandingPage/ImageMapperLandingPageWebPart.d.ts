import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import { IMapArea } from '../models/IMapArea';
export interface IImageMapperLandingPageWebPartProps {
    description: string;
    imageUrl: string;
    imageHeight: string;
    imageWidth: string;
    imageHorizontalPosition: string;
    imageVerticalPosition: string;
    scale: number;
    items: IMapArea[];
}
export default class ImageMapperLandingPageWebPart extends BaseClientSideWebPart<IImageMapperLandingPageWebPartProps> {
    render(): void;
    protected onAddButtonClick(value: any): void;
    protected onDeleteButtonClick(value: any): void;
    private createNewGroup;
    protected onInit(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
    protected onPropertyPaneFieldChanged(propertyPath: string, oldValue: any, newValue: any): void;
}
//# sourceMappingURL=ImageMapperLandingPageWebPart.d.ts.map