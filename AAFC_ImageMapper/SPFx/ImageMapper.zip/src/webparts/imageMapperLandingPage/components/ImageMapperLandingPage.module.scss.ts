/* tslint:disable */
require("./ImageMapperLandingPage.module.css");
const styles = {
  imageMapperLandingPage: 'imageMapperLandingPage_330a8d89',
  image: 'image_330a8d89',
  pointer: 'pointer_330a8d89',
  container: 'container_330a8d89',
  row: 'row_330a8d89',
  column: 'column_330a8d89',
  'ms-Grid': 'ms-Grid_330a8d89',
  title: 'title_330a8d89',
  subTitle: 'subTitle_330a8d89',
  description: 'description_330a8d89',
  button: 'button_330a8d89',
  label: 'label_330a8d89'
};

export default styles;
/* tslint:enable */