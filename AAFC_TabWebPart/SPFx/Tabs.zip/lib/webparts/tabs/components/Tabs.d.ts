import * as React from 'react';
import type { ITabsProps } from './ITabsProps';
export interface ITabsState {
    activeTab: number;
}
export default class Tabs extends React.Component<ITabsProps, ITabsState> {
    constructor(props: ITabsProps);
    private handleTabClick;
    private renderTabsAndContents;
    render(): React.ReactElement<ITabsProps>;
}
//# sourceMappingURL=Tabs.d.ts.map