import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
export interface ITabsWebPartProps {
    description: string;
    sectionClass: string;
    webPartClass: string;
    tabData: any[];
}
export default class TabsWebPart extends BaseClientSideWebPart<ITabsWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    render(): void;
    private getZones;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=TabsWebPart.d.ts.map