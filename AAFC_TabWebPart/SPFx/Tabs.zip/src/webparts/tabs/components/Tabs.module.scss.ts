/* tslint:disable */
require("./Tabs.module.css");
const styles = {
  tabs: 'tabs_b9a1037f',
  container: 'container_b9a1037f',
  row: 'row_b9a1037f',
  column: 'column_b9a1037f',
  'ms-Grid': 'ms-Grid_b9a1037f',
  title: 'title_b9a1037f',
  subTitle: 'subTitle_b9a1037f',
  description: 'description_b9a1037f',
  button: 'button_b9a1037f',
  label: 'label_b9a1037f'
};

export default styles;
/* tslint:enable */