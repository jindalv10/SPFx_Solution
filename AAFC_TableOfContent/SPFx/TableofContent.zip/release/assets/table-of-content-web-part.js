define("ebc6f85d-5e0f-4ae7-a36d-48ce30720bd9_0.0.1", ["@microsoft/sp-property-pane","@microsoft/sp-component-base","@microsoft/sp-lodash-subset","@microsoft/sp-core-library","@microsoft/sp-webpart-base","react","TableOfContentWebPartStrings","react-dom"], function(__WEBPACK_EXTERNAL_MODULE__26ea__, __WEBPACK_EXTERNAL_MODULE__7Awa__, __WEBPACK_EXTERNAL_MODULE_Pk8u__, __WEBPACK_EXTERNAL_MODULE_UWqr__, __WEBPACK_EXTERNAL_MODULE_br4S__, __WEBPACK_EXTERNAL_MODULE_cDcd__, __WEBPACK_EXTERNAL_MODULE_cUXB__, __WEBPACK_EXTERNAL_MODULE_faye__) { return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "LLLj");
/******/ })
/************************************************************************/
/******/ ({

/***/ "26ea":
/*!**********************************************!*\
  !*** external "@microsoft/sp-property-pane" ***!
  \**********************************************/
/*! no static exports found */
/*! exports used: PropertyPaneCheckbox, PropertyPaneDropdown, PropertyPaneLabel, PropertyPaneTextField, PropertyPaneToggle */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE__26ea__;

/***/ }),

/***/ "7Awa":
/*!***********************************************!*\
  !*** external "@microsoft/sp-component-base" ***!
  \***********************************************/
/*! no static exports found */
/*! exports used: ThemeProvider */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE__7Awa__;

/***/ }),

/***/ "HZZk":
/*!******************************************************************!*\
  !*** ./lib/webparts/tableOfContent/components/TableOfContent.js ***!
  \******************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _TableOfContent_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TableOfContent.module.scss */ "ysj4");
/* harmony import */ var _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-lodash-subset */ "Pk8u");
/* harmony import */ var _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! TableOfContentWebPartStrings */ "cUXB");
/* harmony import */ var TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_3__);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();




var TableOfContents = /** @class */ (function (_super) {
    __extends(TableOfContents, _super);
    /**
     * Create a state for the history count.
     * This is required to make sure we go back to the correct page when the back to previous page link is clicked.
     */
    function TableOfContents(props) {
        var _this = _super.call(this, props) || this;
        /**
         * Returns a click handler that scrolls a page to the specified element.
         */
        /* eslint-disable @typescript-eslint/no-explicit-any */
        _this.scrollToHeader = function (target) {
            /* eslint-disable @typescript-eslint/no-explicit-any */
            return function (event) {
                //decrement the history count to allow the return to previous page to work correctly
                var temp = _this.state.historyCount - 1;
                _this.setState({ historyCount: temp });
                event.preventDefault();
                document.location.hash = target.id;
                target.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
            };
        };
        /**
         * Render the back to previous link
         */
        _this.renderBackToPreviousLink = function (listStyle) {
            return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", { className: _TableOfContent_module_scss__WEBPACK_IMPORTED_MODULE_1__[/* default */ "e"].backItem },
                react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("ul", { style: { listStyleType: listStyle } },
                    react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("li", null,
                        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("a", { href: "#", onClick: function () { return _this.backToPreviousPage(); } }, _this.props.previousPageText ? _this.props.previousPageText : TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_3__["previousPageDefaultValue"])))));
        };
        _this.state = {
            historyCount: -1
        };
        return _this;
    }
    /**
     * Gets a nested list of links based on the list of headers specified.
     * @param headers List of HtmlElements for H2, H3, and H4 headers.
     */
    TableOfContents.prototype.getLinks = function (headers) {
        // create a root link that will be a root for links' tree
        var root = { childNodes: [], parent: undefined, element: undefined };
        var prevLink = null;
        for (var i = 0; i < headers.length; i++) {
            var header = headers[i];
            var link = { childNodes: [], parent: undefined, element: header };
            if (i === 0) {
                // the first header is always added as a child of the root
                link.parent = root;
                root.childNodes.push(link);
            }
            else {
                var prevHeader = headers[i - 1];
                // compare the current header and the previous one to define where to add new link
                var compare = this.compareHeaders(header.tagName, prevHeader.tagName);
                if (compare === 0) {
                    // if headers are on the same level, add header to the same parent
                    link.parent = prevLink.parent;
                    prevLink.parent.childNodes.push(link);
                }
                else if (compare < 0) {
                    var targetParent = prevLink.parent;
                    // if current header is bigger than the previous one, go up in the hierarchy to find a place to add link
                    // go up in the hierarchy of links until a link with bigger tag is found or until the root link found
                    // i.e. for H4 look for H3 or H2, for H3 look for H2, for H2 look for the root.
                    while ((targetParent !== root) && (this.compareHeaders(header.tagName, targetParent.element.tagName) <= 0)) {
                        targetParent = targetParent.parent;
                    }
                    link.parent = targetParent;
                    targetParent.childNodes.push(link);
                }
                else {
                    // if current header is smaller than the previous one, add link for it as a child of the previous link
                    link.parent = prevLink;
                    prevLink.childNodes.push(link);
                }
            }
            prevLink = link;
        }
        // return list of links for top-level headers
        return root.childNodes;
    };
    /**
     * Compares two header tags by their weights.
     * The function is used to compare the size of headers (e.g. should H3 go under H2?)
     * @param header1
     * @param header2
     */
    TableOfContents.prototype.compareHeaders = function (header1, header2) {
        return this.getHeaderWeight(header1) - this.getHeaderWeight(header2);
    };
    /**
     * Returns a digital weight of a tag. Used for comparing header tags.
     * @param header
     */
    TableOfContents.prototype.getHeaderWeight = function (header) {
        switch (header.toLowerCase()) {
            case (TableOfContents.h2Tag):
                return 2;
            case (TableOfContents.h3Tag):
                return 3;
            case (TableOfContents.h4Tag):
                return 4;
            case (TableOfContents.h5Tag):
                return 5;
            default:
                throw new Error('Unknown header: ' + header);
        }
    };
    /**
     * Returns html elements in the current page specified by the query selector.
     */
    TableOfContents.prototype.getHtmlElements = function (querySelector) {
        if (querySelector.length === 0) {
            return [];
        }
        else {
            var elements = document.querySelectorAll(querySelector);
            var htmlElements = [];
            for (var i = 0; i < elements.length; i++) {
                // While in edit mode Section headers are not headers, but text areas. This converts them to H2 tags
                if (elements[i].tagName === "TEXTAREA") {
                    var temp = document.createElement('h2');
                    temp.innerHTML = elements[i].innerHTML;
                    htmlElements.push(temp);
                }
                else {
                    htmlElements.push(elements[i]);
                }
            }
            return htmlElements;
        }
    };
    /**
     * Returns a query selector based on the specified props
     * @param props
     */
    TableOfContents.prototype.getQuerySelector = function (props) {
        var queryParts = [];
        var queryItems = [];
        if (this.props.searchText) {
            queryItems.push('.cke_editable', '.ck-content');
        }
        if (this.props.searchCollapsible) {
            queryItems.push('[data-automation-id*="CanvasZone-SectionContainer"]');
        }
        if (this.props.searchMarkdown) {
            queryItems.push('[data-sp-feature-tag*="Markdown"]');
        }
        if (props.showHeading2) {
            for (var i = 0; i < queryItems.length; i++) {
                if (queryItems[i] === '[data-automation-id*="CollapsibleLayer-TitleInput"]') {
                    queryParts.push(queryItems[i]);
                }
                else {
                    queryParts.push(queryItems[i] + " " + TableOfContents.h2Tag);
                }
            }
        }
        if (props.showHeading3) {
            for (var i = 0; i < queryItems.length; i++) {
                queryParts.push(queryItems[i] + " " + TableOfContents.h3Tag);
            }
        }
        if (props.showHeading4) {
            for (var i = 0; i < queryItems.length; i++) {
                queryParts.push(queryItems[i] + " " + TableOfContents.h4Tag);
            }
        }
        if (props.showHeading5) {
            for (var i = 0; i < queryItems.length; i++) {
                queryParts.push(queryItems[i] + " " + TableOfContents.h5Tag);
            }
        }
        return queryParts.join(',');
    };
    /**
     * Filters elements with empty text.
     * @param element
     */
    TableOfContents.prototype.filterEmpty = function (element) {
        // Check if element is empty. If it is in a collapsible section with a 'Premalink' then return true as we can fix that later.
        if (element.innerText.trim() !== '') {
            return true;
        }
        else if (element.firstElementChild !== null) {
            if (element.firstElementChild.getAttribute('role') === 'link') {
                return true;
            }
            else {
                return false;
            }
        }
    };
    /**
     * Filters elements that are inside <aside> tag and thus not related to a page.
     * @param element
     */
    TableOfContents.prototype.filterAside = function (element) {
        var inAsideTag = false;
        var parentElement = element.parentElement;
        while (parentElement) {
            if (parentElement.tagName.toLocaleLowerCase() === 'aside') {
                inAsideTag = true;
                break;
            }
            parentElement = parentElement.parentElement;
        }
        return !inAsideTag;
    };
    /**
     * Filters elements that have the data attrribute of 'data-toc-ignore' and thus should be ignored.
     * @param element
     */
    TableOfContents.prototype.filterTocIgnore = function (element) {
        return !(element.getAttribute("data-toc-ignore"));
    };
    /**
     * Filters elements that have been set with a sytle of 'display: none'
     * @param element
     */
    TableOfContents.prototype.filterStyleDisplayNone = function (element) {
        var styleDisplayNone = false;
        var parentElement = element.parentElement;
        while (parentElement) {
            if (parentElement.style.display.toLocaleLowerCase() === 'none') {
                styleDisplayNone = true;
                break;
            }
            parentElement = parentElement.parentElement;
        }
        return !styleDisplayNone;
    };
    /**
     * Creates a list of components to display from a list of links.
     * @param links
     */
    TableOfContents.prototype.renderLinks = function (links, listStyle) {
        var _this = this;
        // For each link render a <li> element with a link. If the link has got childNodes, additionaly render <ul> with child links.
        var elements = links.map(function (link, index) {
            var linkText = link.element.innerText;
            var regex = /title="Permalink for ([^"]+)"/;
            // If linkText is empty, extract the text from the 'Permalink'
            if (linkText === "") {
                if (link.element.firstElementChild.getAttribute('role') === 'link') {
                    var match = link.element.innerHTML.match(regex);
                    if (match.length >= 2) {
                        linkText = match[1];
                    }
                    else {
                        linkText = 'Error!';
                    }
                }
                else {
                    linkText = 'Error!';
                }
            }
            return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("li", { key: index },
                react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("a", { onClick: _this.scrollToHeader(link.element), href: '#' + link.element.id }, linkText),
                link.childNodes.length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("ul", { style: { listStyleType: listStyle } }, _this.renderLinks(link.childNodes, listStyle))) : ''));
        });
        return elements;
    };
    /**
     * Force the component to re-render with a specified interval.
     * This is needed to get valid id values for headers to use in links. Right after the rendering headers won't have valid ids, they are assigned later once the whole page got rendered.
     * The component will display the correct list of headers on the first render and will be able to process clicks (as a link to an HTMLElement is stored by the component).
     * Once valid ids got assigned to headers by SharePoint code, the component will get valid ids for headers. This way a link from ToC can be copied by a user and it will be a valid link to a header.
     */
    TableOfContents.prototype.componentDidMount = function () {
        var _this = this;
        setInterval(function () {
            _this.setState({});
        }, TableOfContents.timeout);
    };
    /**
     * Event for the back to previous page link.
     * It uses the history count to work out how many pages to go back, as each click to a header results in history
     */
    TableOfContents.prototype.backToPreviousPage = function () {
        window.history.go(this.state.historyCount);
    };
    /**
     * Modify the CSS of the appropriate HTML elements based on the wepart ID to enable sticky mode.
     * This does involve modifying HTML elements outside of the webpart, so may well break in the furture if Microsoft change their HTML\CSS etc.
     */
    TableOfContents.prototype.configureSticky = function () {
        var HTMLElementSticky = document.querySelector("[id='" + this.props.webpartId + "']");
        if (HTMLElementSticky !== null) {
            if (this.props.enableStickyMode && window.innerWidth > 1024) {
                HTMLElementSticky.parentElement.parentElement.parentElement.style.position = "sticky";
                HTMLElementSticky.parentElement.parentElement.parentElement.style.top = "0px";
                HTMLElementSticky.style.position = "fixed";
            }
            else {
                HTMLElementSticky.parentElement.parentElement.parentElement.style.position = "";
                HTMLElementSticky.parentElement.parentElement.parentElement.style.top = "";
                HTMLElementSticky.style.position = "";
            }
        }
    };
    TableOfContents.prototype.render = function () {
        // get headers, then filter out empty and headers from <aside> tags
        var listStyle = Object(_microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2__["escape"])(this.props.listStyle) === "default" ? "" : this.props.listStyle;
        var querySelector = this.getQuerySelector(this.props);
        var headers = this.getHtmlElements(querySelector).filter(this.filterEmpty).filter(this.filterAside).filter(this.filterTocIgnore).filter(this.filterStyleDisplayNone);
        // create a list of links from headers
        var links = this.getLinks(headers);
        // create components from a list of links
        var toc = (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("ul", { style: { listStyleType: listStyle } }, this.renderLinks(links, listStyle)));
        // create previous page link
        var previousPageTitle = this.props.showPreviousPageLinkTitle && !this.props.hideTitle ? (this.renderBackToPreviousLink(listStyle)) : null;
        var previousPageAbove = this.props.showPreviousPageLinkAbove ? (this.renderBackToPreviousLink(listStyle)) : null;
        var previousPageBelow = this.props.showPreviousPageLinkBelow ? (this.renderBackToPreviousLink(listStyle)) : null;
        // add CSS class to hide in mobile view if needed
        var hideInMobileViewClass = this.props.hideInMobileView ? (_TableOfContent_module_scss__WEBPACK_IMPORTED_MODULE_1__[/* default */ "e"].hideInMobileView) : '';
        // add CSS class to hide title if requested
        var titleClass = this.props.hideTitle ? (_TableOfContent_module_scss__WEBPACK_IMPORTED_MODULE_1__[/* default */ "e"].hideTitle) : "cke_editable h2 " + _TableOfContent_module_scss__WEBPACK_IMPORTED_MODULE_1__[/* default */ "e"].title;
        // set title text
        var titleText = this.props.titleText ? this.props.titleText : TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_3__["titleDefaultValue"];
        // set Sticky parameters
        this.configureSticky();
        return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("section", { className: _TableOfContent_module_scss__WEBPACK_IMPORTED_MODULE_1__[/* default */ "e"].tableOfContent },
            react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", { className: hideInMobileViewClass },
                react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("nav", null,
                    previousPageTitle,
                    react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", { className: titleClass },
                        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h2", { "data-toc-ignore": "true" }, titleText)),
                    previousPageAbove,
                    toc,
                    previousPageBelow))));
    };
    TableOfContents.timeout = 500;
    TableOfContents.h2Tag = "h2";
    TableOfContents.h3Tag = "h3";
    TableOfContents.h4Tag = "h4";
    TableOfContents.h5Tag = "h5";
    return TableOfContents;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]));
/* harmony default export */ __webpack_exports__["e"] = (TableOfContents);


/***/ }),

/***/ "JPst":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
// eslint-disable-next-line func-names
module.exports = function (useSourceMap) {
  var list = []; // return the list of modules as css string

  list.toString = function toString() {
    return this.map(function (item) {
      var content = cssWithMappingToString(item, useSourceMap);

      if (item[2]) {
        return "@media ".concat(item[2], " {").concat(content, "}");
      }

      return content;
    }).join('');
  }; // import a list of modules into the list
  // eslint-disable-next-line func-names


  list.i = function (modules, mediaQuery, dedupe) {
    if (typeof modules === 'string') {
      // eslint-disable-next-line no-param-reassign
      modules = [[null, modules, '']];
    }

    var alreadyImportedModules = {};

    if (dedupe) {
      for (var i = 0; i < this.length; i++) {
        // eslint-disable-next-line prefer-destructuring
        var id = this[i][0];

        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }

    for (var _i = 0; _i < modules.length; _i++) {
      var item = [].concat(modules[_i]);

      if (dedupe && alreadyImportedModules[item[0]]) {
        // eslint-disable-next-line no-continue
        continue;
      }

      if (mediaQuery) {
        if (!item[2]) {
          item[2] = mediaQuery;
        } else {
          item[2] = "".concat(mediaQuery, " and ").concat(item[2]);
        }
      }

      list.push(item);
    }
  };

  return list;
};

function cssWithMappingToString(item, useSourceMap) {
  var content = item[1] || ''; // eslint-disable-next-line prefer-destructuring

  var cssMapping = item[3];

  if (!cssMapping) {
    return content;
  }

  if (useSourceMap && typeof btoa === 'function') {
    var sourceMapping = toComment(cssMapping);
    var sourceURLs = cssMapping.sources.map(function (source) {
      return "/*# sourceURL=".concat(cssMapping.sourceRoot || '').concat(source, " */");
    });
    return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
  }

  return [content].join('\n');
} // Adapted from convert-source-map (MIT)


function toComment(sourceMap) {
  // eslint-disable-next-line no-undef
  var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
  var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
  return "/*# ".concat(data, " */");
}

/***/ }),

/***/ "LLLj":
/*!**************************************************************!*\
  !*** ./lib/webparts/tableOfContent/TableOfContentWebPart.js ***!
  \**************************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "faye");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-core-library */ "UWqr");
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/sp-webpart-base */ "br4S");
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @microsoft/sp-property-pane */ "26ea");
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _microsoft_sp_component_base__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @microsoft/sp-component-base */ "7Awa");
/* harmony import */ var _microsoft_sp_component_base__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_component_base__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! TableOfContentWebPartStrings */ "cUXB");
/* harmony import */ var TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_TableOfContent__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/TableOfContent */ "HZZk");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();








var TableOfContentWebPart = /** @class */ (function (_super) {
    __extends(TableOfContentWebPart, _super);
    function TableOfContentWebPart() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.checkToggleField = function (value) {
            if (value === "") {
                return TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["errorToggleFieldEmpty"];
            }
            else {
                return "";
            }
        };
        return _this;
    }
    TableOfContentWebPart.prototype.onInit = function () {
        var _this = this;
        // Consume the ThemeProvider service
        this._themeProvider = this.context.serviceScope.consume(_microsoft_sp_component_base__WEBPACK_IMPORTED_MODULE_5__["ThemeProvider"].serviceKey);
        // If it exists, get the theme variant
        this._themeVariant = this._themeProvider.tryGetTheme();
        this.setCSSVariables(this._themeVariant.semanticColors);
        // Register a handler to be notified if the theme variant changes
        this._themeProvider.themeChangedEvent.add(this, this._handleThemeChangedEvent);
        // return super.onInit()
        return _super.prototype.onInit.call(this).then(function (_) {
            if (_this.properties.searchText === undefined) {
                _this.properties.searchText = true;
                _this.properties.showHeading4 = true;
            }
        });
    };
    /* eslint-disable @typescript-eslint/no-explicit-any */
    TableOfContentWebPart.prototype.setCSSVariables = function (theming) {
        var _this = this;
        if (!theming) {
            return null;
        }
        /* eslint-disable @typescript-eslint/no-explicit-any */
        var themingKeys = Object.keys(theming);
        if (themingKeys !== null) {
            themingKeys.forEach(function (key) {
                _this.domElement.style.setProperty("--".concat(key), theming[key]);
            });
        }
    };
    /**
   * Update the current theme variant reference and re-render.
   *
   * @param args The new theme
   */
    TableOfContentWebPart.prototype._handleThemeChangedEvent = function (args) {
        this._themeVariant = args.theme;
        this.setCSSVariables(this._themeVariant.semanticColors);
        this.render();
    };
    TableOfContentWebPart.prototype.render = function () {
        var element = react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_components_TableOfContent__WEBPACK_IMPORTED_MODULE_7__[/* default */ "e"], {
            themeVariant: this._themeVariant,
            hideTitle: this.properties.hideTitle,
            titleText: this.properties.titleText,
            searchText: this.properties.searchText,
            searchMarkdown: this.properties.searchMarkdown,
            searchCollapsible: this.properties.searchCollapsible,
            showHeading2: this.properties.showHeading1,
            showHeading3: this.properties.showHeading2,
            showHeading4: this.properties.showHeading3,
            showHeading5: this.properties.showHeading4,
            showPreviousPageLinkTitle: this.properties.showPreviousPageLinkTitle,
            showPreviousPageLinkAbove: this.properties.showPreviousPageLinkAbove,
            showPreviousPageLinkBelow: this.properties.showPreviousPageLinkBelow,
            previousPageText: this.properties.previousPageText,
            enableStickyMode: this.properties.enableStickyMode,
            webpartId: this.context.instanceId,
            hideInMobileView: this.properties.hideInMobileView,
            listStyle: this.properties.listStyle
        });
        react_dom__WEBPACK_IMPORTED_MODULE_1__["render"](element, this.domElement);
    };
    /**
     * Saves new value for the title property.
     */
    /*private handleUpdateProperty = (newValue: string) => {
      this.properties.title = newValue;
    }*/
    TableOfContentWebPart.prototype.onDispose = function () {
        react_dom__WEBPACK_IMPORTED_MODULE_1__["unmountComponentAtNode"](this.domElement);
    };
    Object.defineProperty(TableOfContentWebPart.prototype, "dataVersion", {
        get: function () {
            return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__["Version"].parse('1.0');
        },
        enumerable: false,
        configurable: true
    });
    TableOfContentWebPart.prototype.getPropertyPaneConfiguration = function () {
        var showHeading4;
        var showPreviousPageLinkTitle;
        if (this.properties.searchMarkdown) {
            showHeading4 = Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('showHeading4', {
                text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showHeading4FieldLabel"]
            });
        }
        else {
            showHeading4 = Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('showHeading4', {
                text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showHeading4FieldLabel"],
                disabled: true
            });
        }
        if (this.properties.hideTitle) {
            showPreviousPageLinkTitle = Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('showPreviousPageLinkTitle', {
                text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showPreviousPageTitleLabel"],
                disabled: true
            });
        }
        else {
            showPreviousPageLinkTitle = Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('showPreviousPageLinkTitle', {
                text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showPreviousPageTitleLabel"]
            });
        }
        return {
            pages: [
                {
                    header: {
                        description: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["propertyPaneDescription"]
                    },
                    groups: [
                        {
                            groupFields: [
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneToggle"])('hideTitle', {
                                    label: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["hideTitleFieldLabel"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneTextField"])('titleText', {
                                    description: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["titleFieldDescription"],
                                    disabled: this.properties.hideTitle,
                                    onGetErrorMessage: this.checkToggleField,
                                    value: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["titleDefaultValue"]
                                }),
                            ]
                        },
                        {
                            groupFields: [
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneLabel"])('searchWebpartsLabel', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["searchWebpartsLabel"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('searchText', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["searchText"],
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('searchMarkdown', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["searchMarkdown"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('searchCollapsible', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["searchCollapsible"]
                                }),
                            ]
                        },
                        {
                            groupFields: [
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneLabel"])('showHeadingLevelsLabel', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showHeadingLevelsLabel"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('showHeading1', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showHeading1FieldLabel"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('showHeading2', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showHeading2FieldLabel"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('showHeading3', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showHeading3FieldLabel"]
                                }),
                                showHeading4,
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneDropdown"])('listStyle', {
                                    label: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["listStyle"],
                                    options: [
                                        { key: 'default', text: 'Default' },
                                        { key: 'disc', text: 'Disc' },
                                        { key: 'circle', text: 'Circle' },
                                        { key: 'square', text: 'Square' },
                                        { key: 'none', text: 'None' }
                                    ],
                                    selectedKey: "default"
                                }),
                            ]
                        },
                        {
                            groupFields: [
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneLabel"])('previousPageLabel', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showPreviousPageViewLabel"]
                                }),
                                showPreviousPageLinkTitle,
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('showPreviousPageLinkAbove', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showPreviousPageAboveLabel"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneCheckbox"])('showPreviousPageLinkBelow', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["showPreviousPageBelowLabel"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneTextField"])('previousPageText', {
                                    label: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["previousPageFieldLabel"],
                                    disabled: (!this.properties.showPreviousPageLinkTitle || this.properties.hideTitle) && !this.properties.showPreviousPageLinkAbove && !this.properties.showPreviousPageLinkBelow,
                                    onGetErrorMessage: this.checkToggleField,
                                    value: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["previousPageDefaultValue"]
                                }),
                            ]
                        },
                        {
                            groupFields: [
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneToggle"])('enableStickyMode', {
                                    label: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["enableStickyModeLabel"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneLabel"])('enabldeStickyModeDescription', {
                                    text: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["enableStickyModeDescription"]
                                }),
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_4__["PropertyPaneToggle"])('hideInMobileView', {
                                    label: TableOfContentWebPartStrings__WEBPACK_IMPORTED_MODULE_6__["hideInMobileViewLabel"]
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return TableOfContentWebPart;
}(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_3__["BaseClientSideWebPart"]));
/* harmony default export */ __webpack_exports__["default"] = (TableOfContentWebPart);


/***/ }),

/***/ "Pk8u":
/*!**********************************************!*\
  !*** external "@microsoft/sp-lodash-subset" ***!
  \**********************************************/
/*! no static exports found */
/*! exports used: escape */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_Pk8u__;

/***/ }),

/***/ "UWqr":
/*!*********************************************!*\
  !*** external "@microsoft/sp-core-library" ***!
  \*********************************************/
/*! no static exports found */
/*! exports used: Version */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_UWqr__;

/***/ }),

/***/ "VfqV":
/*!********************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js??ref--6-2!./lib/webparts/tableOfContent/components/TableOfContent.module.css ***!
  \********************************************************************************************************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "JPst");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".tableOfContent_03a6fdfc a{color:var(--actionLink);text-decoration:none}.tableOfContent_03a6fdfc a:hover{color:var(--actionLink);text-decoration:underline}.tableOfContent_03a6fdfc a:visited{color:var(--actionLink)}.tableOfContent_03a6fdfc li::marker{color:var(--primaryButtonBackground)}.tableOfContent_03a6fdfc .backItem_03a6fdfc{border-bottom:1px solid;border-top:1px solid;border-color:var(--menuDivider);margin-bottom:10px}@media only screen and (max-width:1023.99999px){.tableOfContent_03a6fdfc .hideInMobileView_03a6fdfc{display:none!important}}.tableOfContent_03a6fdfc .title_03a6fdfc{min-height:auto}.tableOfContent_03a6fdfc .hideTitle_03a6fdfc{display:none!important}.tableOfContent_03a6fdfc .navigationBar_03a6fdfc{width:400px!important}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "br4S":
/*!*********************************************!*\
  !*** external "@microsoft/sp-webpart-base" ***!
  \*********************************************/
/*! no static exports found */
/*! exports used: BaseClientSideWebPart */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_br4S__;

/***/ }),

/***/ "cDcd":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/*! exports used: Component, createElement */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_cDcd__;

/***/ }),

/***/ "cUXB":
/*!***********************************************!*\
  !*** external "TableOfContentWebPartStrings" ***!
  \***********************************************/
/*! no static exports found */
/*! exports used: enableStickyModeDescription, enableStickyModeLabel, errorToggleFieldEmpty, hideInMobileViewLabel, hideTitleFieldLabel, listStyle, previousPageDefaultValue, previousPageFieldLabel, propertyPaneDescription, searchCollapsible, searchMarkdown, searchText, searchWebpartsLabel, showHeading1FieldLabel, showHeading2FieldLabel, showHeading3FieldLabel, showHeading4FieldLabel, showHeadingLevelsLabel, showPreviousPageAboveLabel, showPreviousPageBelowLabel, showPreviousPageTitleLabel, showPreviousPageViewLabel, titleDefaultValue, titleFieldDescription */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_cUXB__;

/***/ }),

/***/ "d0zJ":
/*!**************************************************************************!*\
  !*** ./lib/webparts/tableOfContent/components/TableOfContent.module.css ***!
  \**************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/dist/cjs.js??ref--6-2!./TableOfContent.module.css */ "VfqV");
var loader = __webpack_require__(/*! ./node_modules/@microsoft/load-themed-styles/lib/index.js */ "xMn6");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "faye":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/*! no static exports found */
/*! exports used: render, unmountComponentAtNode */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_faye__;

/***/ }),

/***/ "xMn6":
/*!*****************************************************************!*\
  !*** ./node_modules/@microsoft/load-themed-styles/lib/index.js ***!
  \*****************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {
// Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
// See LICENSE in the project root for license information.
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClearStyleOptions = exports.Mode = void 0;
exports.loadStyles = loadStyles;
exports.configureLoadStyles = configureLoadStyles;
exports.configureRunMode = configureRunMode;
exports.flush = flush;
exports.loadTheme = loadTheme;
exports.clearStyles = clearStyles;
exports.detokenize = detokenize;
exports.splitStyles = splitStyles;
/**
 * In sync mode, styles are registered as style elements synchronously with loadStyles() call.
 * In async mode, styles are buffered and registered as batch in async timer for performance purpose.
 */
var Mode;
(function (Mode) {
    Mode[Mode["sync"] = 0] = "sync";
    Mode[Mode["async"] = 1] = "async";
})(Mode || (exports.Mode = Mode = {}));
/**
 * Themable styles and non-themable styles are tracked separately
 * Specify ClearStyleOptions when calling clearStyles API to specify which group of registered styles should be cleared.
 */
var ClearStyleOptions;
(function (ClearStyleOptions) {
    /** only themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["onlyThemable"] = 1] = "onlyThemable";
    /** only non-themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["onlyNonThemable"] = 2] = "onlyNonThemable";
    /** both themable and non-themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["all"] = 3] = "all";
})(ClearStyleOptions || (exports.ClearStyleOptions = ClearStyleOptions = {}));
// Store the theming state in __themeState__ global scope for reuse in the case of duplicate
// load-themed-styles hosted on the page.
var _root = typeof window === 'undefined' ? global : window; // eslint-disable-line @typescript-eslint/no-explicit-any
// Nonce string to inject into script tag if one provided. This is used in CSP (Content Security Policy).
var _styleNonce = _root && _root.CSPSettings && _root.CSPSettings.nonce;
var _themeState = initializeThemeState();
/**
 * Matches theming tokens. For example, "[theme: themeSlotName, default: #FFF]" (including the quotes).
 */
var _themeTokenRegex = /[\'\"]\[theme:\s*(\w+)\s*(?:\,\s*default:\s*([\\"\']?[\.\,\(\)\#\-\s\w]*[\.\,\(\)\#\-\w][\"\']?))?\s*\][\'\"]/g;
var now = function () {
    return typeof performance !== 'undefined' && !!performance.now ? performance.now() : Date.now();
};
function measure(func) {
    var start = now();
    func();
    var end = now();
    _themeState.perf.duration += end - start;
}
/**
 * initialize global state object
 */
function initializeThemeState() {
    var state = _root.__themeState__ || {
        theme: undefined,
        lastStyleElement: undefined,
        registeredStyles: []
    };
    if (!state.runState) {
        state = __assign(__assign({}, state), { perf: {
                count: 0,
                duration: 0
            }, runState: {
                flushTimer: 0,
                mode: Mode.sync,
                buffer: []
            } });
    }
    if (!state.registeredThemableStyles) {
        state = __assign(__assign({}, state), { registeredThemableStyles: [] });
    }
    _root.__themeState__ = state;
    return state;
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load
 * event is fired.
 * @param {string | ThemableArray} styles Themable style text to register.
 * @param {boolean} loadAsync When true, always load styles in async mode, irrespective of current sync mode.
 */
function loadStyles(styles, loadAsync) {
    if (loadAsync === void 0) { loadAsync = false; }
    measure(function () {
        var styleParts = Array.isArray(styles) ? styles : splitStyles(styles);
        var _a = _themeState.runState, mode = _a.mode, buffer = _a.buffer, flushTimer = _a.flushTimer;
        if (loadAsync || mode === Mode.async) {
            buffer.push(styleParts);
            if (!flushTimer) {
                _themeState.runState.flushTimer = asyncLoadStyles();
            }
        }
        else {
            applyThemableStyles(styleParts);
        }
    });
}
/**
 * Allows for customizable loadStyles logic. e.g. for server side rendering application
 * @param {(processedStyles: string, rawStyles?: string | ThemableArray) => void}
 * a loadStyles callback that gets called when styles are loaded or reloaded
 */
function configureLoadStyles(loadStylesFn) {
    _themeState.loadStyles = loadStylesFn;
}
/**
 * Configure run mode of load-themable-styles
 * @param mode load-themable-styles run mode, async or sync
 */
function configureRunMode(mode) {
    _themeState.runState.mode = mode;
}
/**
 * external code can call flush to synchronously force processing of currently buffered styles
 */
function flush() {
    measure(function () {
        var styleArrays = _themeState.runState.buffer.slice();
        _themeState.runState.buffer = [];
        var mergedStyleArray = [].concat.apply([], styleArrays);
        if (mergedStyleArray.length > 0) {
            applyThemableStyles(mergedStyleArray);
        }
    });
}
/**
 * register async loadStyles
 */
function asyncLoadStyles() {
    // Use "self" to distinguish conflicting global typings for setTimeout() from lib.dom.d.ts vs Jest's @types/node
    // https://github.com/jestjs/jest/issues/14418
    return self.setTimeout(function () {
        _themeState.runState.flushTimer = 0;
        flush();
    }, 0);
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load event
 * is fired.
 * @param {string} styleText Style to register.
 * @param {IStyleRecord} styleRecord Existing style record to re-apply.
 */
function applyThemableStyles(stylesArray, styleRecord) {
    if (_themeState.loadStyles) {
        _themeState.loadStyles(resolveThemableArray(stylesArray).styleString, stylesArray);
    }
    else {
        registerStyles(stylesArray);
    }
}
/**
 * Registers a set theme tokens to find and replace. If styles were already registered, they will be
 * replaced.
 * @param {theme} theme JSON object of theme tokens to values.
 */
function loadTheme(theme) {
    _themeState.theme = theme;
    // reload styles.
    reloadStyles();
}
/**
 * Clear already registered style elements and style records in theme_State object
 * @param option - specify which group of registered styles should be cleared.
 * Default to be both themable and non-themable styles will be cleared
 */
function clearStyles(option) {
    if (option === void 0) { option = ClearStyleOptions.all; }
    if (option === ClearStyleOptions.all || option === ClearStyleOptions.onlyNonThemable) {
        clearStylesInternal(_themeState.registeredStyles);
        _themeState.registeredStyles = [];
    }
    if (option === ClearStyleOptions.all || option === ClearStyleOptions.onlyThemable) {
        clearStylesInternal(_themeState.registeredThemableStyles);
        _themeState.registeredThemableStyles = [];
    }
}
function clearStylesInternal(records) {
    records.forEach(function (styleRecord) {
        var styleElement = styleRecord && styleRecord.styleElement;
        if (styleElement && styleElement.parentElement) {
            styleElement.parentElement.removeChild(styleElement);
        }
    });
}
/**
 * Reloads styles.
 */
function reloadStyles() {
    if (_themeState.theme) {
        var themableStyles = [];
        for (var _i = 0, _a = _themeState.registeredThemableStyles; _i < _a.length; _i++) {
            var styleRecord = _a[_i];
            themableStyles.push(styleRecord.themableStyle);
        }
        if (themableStyles.length > 0) {
            clearStyles(ClearStyleOptions.onlyThemable);
            applyThemableStyles([].concat.apply([], themableStyles));
        }
    }
}
/**
 * Find theme tokens and replaces them with provided theme values.
 * @param {string} styles Tokenized styles to fix.
 */
function detokenize(styles) {
    if (styles) {
        styles = resolveThemableArray(splitStyles(styles)).styleString;
    }
    return styles;
}
/**
 * Resolves ThemingInstruction objects in an array and joins the result into a string.
 * @param {ThemableArray} splitStyleArray ThemableArray to resolve and join.
 */
function resolveThemableArray(splitStyleArray) {
    var theme = _themeState.theme;
    var themable = false;
    // Resolve the array of theming instructions to an array of strings.
    // Then join the array to produce the final CSS string.
    var resolvedArray = (splitStyleArray || []).map(function (currentValue) {
        var themeSlot = currentValue.theme;
        if (themeSlot) {
            themable = true;
            // A theming annotation. Resolve it.
            var themedValue = theme ? theme[themeSlot] : undefined;
            var defaultValue = currentValue.defaultValue || 'inherit';
            // Warn to console if we hit an unthemed value even when themes are provided, but only if "DEBUG" is true.
            // Allow the themedValue to be undefined to explicitly request the default value.
            if (theme &&
                !themedValue &&
                console &&
                !(themeSlot in theme) &&
                "boolean" !== 'undefined' &&
                true) {
                // eslint-disable-next-line no-console
                console.warn("Theming value not provided for \"".concat(themeSlot, "\". Falling back to \"").concat(defaultValue, "\"."));
            }
            return themedValue || defaultValue;
        }
        else {
            // A non-themable string. Preserve it.
            return currentValue.rawString;
        }
    });
    return {
        styleString: resolvedArray.join(''),
        themable: themable
    };
}
/**
 * Split tokenized CSS into an array of strings and theme specification objects
 * @param {string} styles Tokenized styles to split.
 */
function splitStyles(styles) {
    var result = [];
    if (styles) {
        var pos = 0; // Current position in styles.
        var tokenMatch = void 0;
        while ((tokenMatch = _themeTokenRegex.exec(styles))) {
            var matchIndex = tokenMatch.index;
            if (matchIndex > pos) {
                result.push({
                    rawString: styles.substring(pos, matchIndex)
                });
            }
            result.push({
                theme: tokenMatch[1],
                defaultValue: tokenMatch[2] // May be undefined
            });
            // index of the first character after the current match
            pos = _themeTokenRegex.lastIndex;
        }
        // Push the rest of the string after the last match.
        result.push({
            rawString: styles.substring(pos)
        });
    }
    return result;
}
/**
 * Registers a set of style text. If it is registered too early, we will register it when the
 * window.load event is fired.
 * @param {ThemableArray} styleArray Array of IThemingInstruction objects to register.
 * @param {IStyleRecord} styleRecord May specify a style Element to update.
 */
function registerStyles(styleArray) {
    if (typeof document === 'undefined') {
        return;
    }
    var head = document.getElementsByTagName('head')[0];
    var styleElement = document.createElement('style');
    var _a = resolveThemableArray(styleArray), styleString = _a.styleString, themable = _a.themable;
    styleElement.setAttribute('data-load-themed-styles', 'true');
    if (_styleNonce) {
        styleElement.setAttribute('nonce', _styleNonce);
    }
    styleElement.appendChild(document.createTextNode(styleString));
    _themeState.perf.count++;
    head.appendChild(styleElement);
    var ev = document.createEvent('HTMLEvents');
    ev.initEvent('styleinsert', true /* bubbleEvent */, false /* cancelable */);
    ev.args = {
        newStyle: styleElement
    };
    document.dispatchEvent(ev);
    var record = {
        styleElement: styleElement,
        themableStyle: styleArray
    };
    if (themable) {
        _themeState.registeredThemableStyles.push(record);
    }
    else {
        _themeState.registeredStyles.push(record);
    }
}
//# sourceMappingURL=index.js.map
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../webpack/buildin/global.js */ "yLpj")))

/***/ }),

/***/ "yLpj":
/*!***********************************!*\
  !*** (webpack)/buildin/global.js ***!
  \***********************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || new Function("return this")();
} catch (e) {
	// This works if the window reference is available
	if (typeof window === "object") g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ "ysj4":
/*!******************************************************************************!*\
  !*** ./lib/webparts/tableOfContent/components/TableOfContent.module.scss.js ***!
  \******************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* tslint:disable */
__webpack_require__(/*! ./TableOfContent.module.css */ "d0zJ");
var styles = {
    tableOfContent: 'tableOfContent_03a6fdfc',
    backItem: 'backItem_03a6fdfc',
    hideInMobileView: 'hideInMobileView_03a6fdfc',
    title: 'title_03a6fdfc',
    hideTitle: 'hideTitle_03a6fdfc',
    navigationBar: 'navigationBar_03a6fdfc'
};
/* harmony default export */ __webpack_exports__["e"] = (styles);
/* tslint:enable */ 


/***/ })

/******/ })});;
//# sourceMappingURL=table-of-content-web-part.js.map