/* tslint:disable */
require("./TableOfContent.module.css");
const styles = {
  tableOfContent: 'tableOfContent_03a6fdfc',
  backItem: 'backItem_03a6fdfc',
  hideInMobileView: 'hideInMobileView_03a6fdfc',
  title: 'title_03a6fdfc',
  hideTitle: 'hideTitle_03a6fdfc',
  navigationBar: 'navigationBar_03a6fdfc'
};

export default styles;
/* tslint:enable */