export interface ITableOfContentState {
  historyCount: number;
}