export interface ITableOfContentState {
    historyCount: number;
}
//# sourceMappingURL=ITableOfContentState.d.ts.map