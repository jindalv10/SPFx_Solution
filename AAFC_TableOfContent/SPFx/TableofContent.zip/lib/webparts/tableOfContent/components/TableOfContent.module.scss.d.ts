declare const styles: {
    tableOfContent: string;
    backItem: string;
    hideInMobileView: string;
    title: string;
    hideTitle: string;
    navigationBar: string;
};
export default styles;
//# sourceMappingURL=TableOfContent.module.scss.d.ts.map