import * as React from 'react';
import { ITableOfContentProps } from './ITableOfContentProps';
import { ITableOfContentState } from './ITableOfContentState';
export default class TableOfContents extends React.Component<ITableOfContentProps, ITableOfContentState> {
    private static timeout;
    private static h2Tag;
    private static h3Tag;
    private static h4Tag;
    private static h5Tag;
    /**
     * Create a state for the history count.
     * This is required to make sure we go back to the correct page when the back to previous page link is clicked.
     */
    constructor(props: ITableOfContentProps);
    /**
     * Gets a nested list of links based on the list of headers specified.
     * @param headers List of HtmlElements for H2, H3, and H4 headers.
     */
    private getLinks;
    /**
     * Compares two header tags by their weights.
     * The function is used to compare the size of headers (e.g. should H3 go under H2?)
     * @param header1
     * @param header2
     */
    private compareHeaders;
    /**
     * Returns a digital weight of a tag. Used for comparing header tags.
     * @param header
     */
    private getHeaderWeight;
    /**
     * Returns html elements in the current page specified by the query selector.
     */
    private getHtmlElements;
    /**
     * Returns a query selector based on the specified props
     * @param props
     */
    private getQuerySelector;
    /**
     * Filters elements with empty text.
     * @param element
     */
    private filterEmpty;
    /**
     * Filters elements that are inside <aside> tag and thus not related to a page.
     * @param element
     */
    private filterAside;
    /**
     * Filters elements that have the data attrribute of 'data-toc-ignore' and thus should be ignored.
     * @param element
     */
    private filterTocIgnore;
    /**
     * Filters elements that have been set with a sytle of 'display: none'
     * @param element
     */
    private filterStyleDisplayNone;
    /**
     * Returns a click handler that scrolls a page to the specified element.
     */
    private scrollToHeader;
    /**
     * Creates a list of components to display from a list of links.
     * @param links
     */
    private renderLinks;
    /**
     * Force the component to re-render with a specified interval.
     * This is needed to get valid id values for headers to use in links. Right after the rendering headers won't have valid ids, they are assigned later once the whole page got rendered.
     * The component will display the correct list of headers on the first render and will be able to process clicks (as a link to an HTMLElement is stored by the component).
     * Once valid ids got assigned to headers by SharePoint code, the component will get valid ids for headers. This way a link from ToC can be copied by a user and it will be a valid link to a header.
     */
    componentDidMount(): void;
    /**
     * Event for the back to previous page link.
     * It uses the history count to work out how many pages to go back, as each click to a header results in history
     */
    backToPreviousPage(): void;
    /**
     * Render the back to previous link
     */
    private renderBackToPreviousLink;
    /**
     * Modify the CSS of the appropriate HTML elements based on the wepart ID to enable sticky mode.
     * This does involve modifying HTML elements outside of the webpart, so may well break in the furture if Microsoft change their HTML\CSS etc.
     */
    private configureSticky;
    render(): JSX.Element;
}
//# sourceMappingURL=TableOfContent.d.ts.map