import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IPropertyPaneConfiguration } from "@microsoft/sp-property-pane";
import { ITableOfContentProps } from './components/ITableOfContentProps';
export interface ITableOfContentsWebPartProps {
    hideTitle: boolean;
    titleText: string;
    searchText: boolean;
    searchMarkdown: boolean;
    searchCollapsible: boolean;
    showHeading1: boolean;
    showHeading2: boolean;
    showHeading3: boolean;
    showHeading4: boolean;
    showPreviousPageLinkTitle: boolean;
    showPreviousPageLinkAbove: boolean;
    showPreviousPageLinkBelow: boolean;
    previousPageText: string;
    historyCount: number;
    enableStickyMode: boolean;
    hideInMobileView: boolean;
    listStyle: string;
}
export default class TableOfContentWebPart extends BaseClientSideWebPart<ITableOfContentProps> {
    private _themeProvider;
    private _themeVariant;
    protected onInit(): Promise<void>;
    private setCSSVariables;
    /**
   * Update the current theme variant reference and re-render.
   *
   * @param args The new theme
   */
    private _handleThemeChangedEvent;
    render(): void;
    /**
     * Saves new value for the title property.
     */
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
    private checkToggleField;
}
//# sourceMappingURL=TableOfContentWebPart.d.ts.map